# mmx

An old Mega Man X playable demo for TempleOS

I don't think I ever released this, so here it is - for historical purposes

![screenshot](https://git.checksum.fail/alec/mmx/raw/branch/main/screenshot.png)
