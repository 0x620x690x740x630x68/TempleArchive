# gr2png

TempleOS GR -> PNG

# Build

`gcc -o gr2png gr2png.c`

# Usage

`gr2png somefile.GR` will output `somefile.png`
