# todotz

Compress file to TempleOS .Z format

# Build

`g++ -o todotz todotz.cpp`

# Usage

`todotz somefile.ext` will output `somefile.ext.Z`
